# Project Alpha

Project Alpha is a local voice assistant prototype with a modular Python backend:

- STT: microphone to text
- LLM: OpenRouter chat response with personality and memory
- TTS: edge-tts speech playback
- Automation: common app and web actions

## Structure

```text
project/
  main_chat.py
  process/
    automation.py
    events.py
    llm.py
    stt.py
    tts.py
  config/
    config.yaml
    personality.txt
  utils/
    config_loader.py
    memory_db.py
  memory/
    memory.db
```

## Features

- Voice interaction loop (STT -> LLM -> TTS)
- OpenRouter integration
- Character personality prompt from config file
- Persistent SQLite memory
- Automation commands (apps, sites, utilities)
- Optional VAD mode
- Low-latency TTS queue and warmup

## Requirements

- Python 3.10+
- Windows (current setup), Linux/macOS may work with small tweaks
- Microphone and speaker

Install dependencies:

```powershell
pip install -r requirements.txt
pip install -r extra-req.txt
```

## Configuration

Main config is in `config/config.yaml`.

Set your OpenRouter key with environment variable (recommended):

```powershell
$env:OPENROUTER_API_KEY="your_key_here"
```

Or set it in `config/config.yaml` under `llm.openrouter_api_key`.

## Run

```powershell
python main_chat.py
```

## Automation Examples

- open youtube
- open google
- open whatsapp
- open notepad
- open calculator
- what time is it
- search google for python asyncio

## Notes

- Memory is stored in `memory/memory.db`.
- If VAD is enabled, assistant listens continuously.
- If VAD is disabled, press Enter to start each turn.


