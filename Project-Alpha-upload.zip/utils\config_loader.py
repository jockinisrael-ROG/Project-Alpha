from pathlib import Path
from typing import Any, Dict

import yaml


DEFAULT_CONFIG: Dict[str, Any] = {
    "assistant": {
        "name": "Alpha",
        "system_prompt": "You are Alpha, a cute anime tsundere AI assistant. Playful, teasing, slightly rude but caring.",
    },
    "stt": {
        "vad_mode": True,
        "sample_rate": 16000,
        "recording_seconds": 4,
        "max_recording_seconds": 20,
            "speech_start_timeout_seconds": 300,
            "min_speech_seconds": 0.25,
        "recording_file": "audio/recording.wav",
        "whisper_model": "base",
        "language": "en",
        "device": "cpu",
        "compute_type": "int8",
        "silence_threshold": 0.008,
            "threshold_multiplier": 2.5,
        "chunk_seconds": 0.1,
        "max_silence_seconds": 0.45,
    },
    "tts": {
        "voice": "en-US-AnaNeural",
        "output_file": "audio/output.wav",
        "in_memory_mode": True,
        "async_queue": True,
        "warmup": True,
    },
    "llm": {
        "provider": "openrouter",
        "model": "openai/gpt-4o-mini",
        "streaming": True,
        "stream_tts_chunk_chars": 24,
        "stream_tts_min_tail_chars": 6,
        "stream_tts_max_delay_sec": 0.25,
        "openrouter_base_url": "https://openrouter.ai/api/v1",
        "openrouter_model": "openai/gpt-4o-mini",
        "openrouter_api_key": "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",
        "site_url": "http://localhost",
        "app_name": "Alpha Local Assistant",
        "temperature": 0.7,
        "max_history_messages": 12,
    },
    "memory": {
        "db_path": "memory/memory.db",
    },
    "vision": {
        "enabled": True,
        "camera_index": 0,
        "sample_seconds": 0.15,
        "auto_calibration": True,
        "calibration_refresh_minutes": 120,
        "calibration_sample_seconds": 1.8,
    },
}


def _deep_merge(base: Dict[str, Any], updates: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(base)
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_config() -> Dict[str, Any]:
    config_path = Path(__file__).resolve().parent.parent / "config" / "config.yaml"
    if not config_path.exists():
        return DEFAULT_CONFIG

    with config_path.open("r", encoding="utf-8") as file:
        loaded = yaml.safe_load(file) or {}

    return _deep_merge(DEFAULT_CONFIG, loaded)
